# Chronos Independent Diffusion Studio — Fixed Edition

這一版加入完整啟動檢查，不會因為缺少 PyTorch 或模型而直接關閉。

## 新增功能

- Python 與虛擬環境自動檢查
- 自動建立 `.venv`
- 自動安裝網頁與 AI 套件
- 優先嘗試 CUDA PyTorch，失敗後改裝 CPU 版
- 啟動前完整 PRECHECK
- 網頁內系統診斷頁
- 顯示 Python、套件、CUDA、GPU、模型數量
- 自動掃描 models 與 loras
- 模型下拉選單
- 一鍵開啟模型、LoRA、輸出資料夾
- 缺少套件時仍可開啟診斷畫面
- 清楚顯示模型載入錯誤

## 正確使用順序

1. 完整解壓縮 ZIP。
2. 執行 `INSTALL_ALL.bat`。
3. 等待所有套件安裝完成。
4. 將模型放到 `models`。
5. 執行 `START_FIXED.bat`。
6. 瀏覽器開啟 `http://127.0.0.1:7865`。
7. 先查看「系統診斷」。
8. 到「模型管理」重新掃描並載入模型。

## 模型範例

單一模型：

`models\my_model.safetensors`

Diffusers 資料夾：

`models\SDXL\model_index.json`

模型權重不包含在 ZIP 內。
