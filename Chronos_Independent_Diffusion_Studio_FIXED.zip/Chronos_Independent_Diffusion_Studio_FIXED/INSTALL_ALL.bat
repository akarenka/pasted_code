@echo off
setlocal
cd /d "%~dp0"
title Chronos Independent Diffusion Installer
echo ============================================================
echo Chronos Independent Diffusion Studio - Full Installer
echo ============================================================
echo.

where py >nul 2>nul
if not errorlevel 1 (
  set PY=py
) else (
  where python >nul 2>nul
  if errorlevel 1 (
    echo [ERROR] Python was not found.
    echo Install Python 3.10 or 3.11 and enable Add Python to PATH.
    pause
    exit /b 1
  )
  set PY=python
)

%PY% -c "import sys; print('Python:',sys.version); print('Executable:',sys.executable)"
echo.
echo Creating virtual environment...
if not exist ".venv\Scripts\python.exe" %PY% -m venv .venv
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] Failed to create virtual environment.
  pause
  exit /b 1
)

call ".venv\Scripts\activate.bat"
python -m pip install --upgrade pip wheel setuptools
echo.
echo Installing web interface packages...
python -m pip install fastapi "uvicorn[standard]" python-multipart Pillow
echo.
echo Installing AI packages...
python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
if errorlevel 1 (
  echo CUDA PyTorch installation failed. Installing CPU version...
  python -m pip install torch torchvision
)
python -m pip install diffusers transformers accelerate safetensors peft
echo.
echo Verifying installation...
python PRECHECK.py
echo.
echo Installation finished.
pause
