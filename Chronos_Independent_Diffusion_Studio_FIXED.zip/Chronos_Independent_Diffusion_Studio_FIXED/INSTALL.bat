@echo off
cd /d "%~dp0"
title Chronos Diffusion Installer
echo Installing independent diffusion engine...
where py >nul 2>nul
if %errorlevel%==0 (
  py -m pip install --upgrade pip
  py -m pip install -r requirements.txt
) else (
  python -m pip install --upgrade pip
  python -m pip install -r requirements.txt
)
echo.
echo Installation completed.
pause
