@echo off
setlocal
cd /d "%~dp0"
title Chronos Independent Diffusion Studio
if not exist ".venv\Scripts\python.exe" (
  echo [ERROR] The virtual environment is missing.
  echo Run INSTALL_ALL.bat first.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
python PRECHECK.py
start "" http://127.0.0.1:7865
python app.py
echo.
echo The server stopped. Check the messages above.
pause
