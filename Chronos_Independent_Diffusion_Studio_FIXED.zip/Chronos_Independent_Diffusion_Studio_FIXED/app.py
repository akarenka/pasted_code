
from __future__ import annotations
import io
import json
import os
import platform
import socket
import subprocess
import sys
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image

ROOT = Path(__file__).resolve().parent
STATIC = ROOT / "static"
OUTPUTS = ROOT / "outputs"
MODELS = ROOT / "models"
LORAS = ROOT / "loras"
CONFIG_FILE = ROOT / "config.json"
HISTORY_FILE = ROOT / "history.json"

for p in (OUTPUTS, MODELS, LORAS):
    p.mkdir(parents=True, exist_ok=True)

DEFAULT_CONFIG = {
    "model_path": "",
    "device": "cuda",
    "dtype": "float16",
    "low_vram": False,
    "attention_slicing": True,
    "vae_slicing": True
}

def load_json(path: Path, default):
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return default

def save_json(path: Path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

config = {**DEFAULT_CONFIG, **load_json(CONFIG_FILE, {})}
history = load_json(HISTORY_FILE, [])

app = FastAPI(title="Chronos Independent Diffusion Studio")
app.mount("/static", StaticFiles(directory=STATIC), name="static")
app.mount("/outputs", StaticFiles(directory=OUTPUTS), name="outputs")

def module_status(name):
    try:
        mod = __import__(name)
        return {"installed": True, "version": getattr(mod, "__version__", "unknown")}
    except Exception as e:
        return {"installed": False, "error": str(e)}

def diagnostics():
    result = {
        "python": {
            "version": sys.version.split()[0],
            "executable": sys.executable,
            "supported": sys.version_info[:2] in [(3,10), (3,11), (3,12)]
        },
        "system": {
            "platform": platform.platform(),
            "machine": platform.machine()
        },
        "packages": {},
        "cuda": {"available": False},
        "models": scan_models(),
        "loras": scan_loras()
    }
    for name in ["fastapi", "uvicorn", "PIL", "torch", "diffusers", "transformers", "accelerate", "safetensors", "peft"]:
        result["packages"][name] = module_status(name)
    try:
        import torch
        result["cuda"] = {
            "available": torch.cuda.is_available(),
            "torch_cuda": torch.version.cuda,
            "device_count": torch.cuda.device_count(),
            "device_name": torch.cuda.get_device_name(0) if torch.cuda.is_available() else ""
        }
    except Exception as e:
        result["cuda"]["error"] = str(e)

    missing = [k for k,v in result["packages"].items() if not v.get("installed")]
    issues = []
    if missing:
        issues.append("缺少套件：" + ", ".join(missing))
    if not result["models"]:
        issues.append("models 資料夾中沒有可用模型")
    if config.get("device") == "cuda" and not result["cuda"].get("available"):
        issues.append("設定為 CUDA，但 PyTorch 無法使用 CUDA")
    result["issues"] = issues
    result["ready"] = len(issues) == 0
    return result

def scan_models():
    items = []
    for p in MODELS.rglob("*"):
        if p.is_file() and p.suffix.lower() in {".safetensors", ".ckpt"}:
            items.append(str(p))
        elif p.is_dir() and (p / "model_index.json").exists():
            items.append(str(p))
    return sorted(set(items))

def scan_loras():
    return sorted(str(p) for p in LORAS.rglob("*.safetensors"))

class Engine:
    def __init__(self):
        self.pipe = None
        self.img2img_pipe = None
        self.loaded_path = ""
        self.status = "未載入模型"
        self.error = ""
        self.loras = []

    def unload(self):
        self.pipe = None
        self.img2img_pipe = None
        self.loaded_path = ""
        self.loras = []
        try:
            import torch
            if torch.cuda.is_available():
                torch.cuda.empty_cache()
        except Exception:
            pass
        self.status = "模型已卸載"

    def load(self, path):
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"模型不存在：{p}")
        try:
            import torch
            from diffusers import AutoPipelineForText2Image, AutoPipelineForImage2Image
            from diffusers import StableDiffusionPipeline, StableDiffusionXLPipeline
        except Exception as e:
            raise RuntimeError("生成核心尚未安裝。請先執行 INSTALL_ALL.bat。\n" + str(e))

        dtype_name = config.get("dtype", "float16")
        dtype = torch.float16 if dtype_name == "float16" else torch.bfloat16 if dtype_name == "bfloat16" else torch.float32
        self.status = "正在載入模型"
        try:
            if p.is_file():
                try:
                    pipe = StableDiffusionXLPipeline.from_single_file(str(p), torch_dtype=dtype, local_files_only=True)
                except Exception:
                    pipe = StableDiffusionPipeline.from_single_file(str(p), torch_dtype=dtype, local_files_only=True)
            else:
                pipe = AutoPipelineForText2Image.from_pretrained(str(p), torch_dtype=dtype, local_files_only=True)

            device = config.get("device", "cuda")
            if device == "cuda" and not torch.cuda.is_available():
                raise RuntimeError("CUDA 不可用。請在設定改成 CPU，或安裝支援 CUDA 的 PyTorch。")

            if config.get("low_vram") and device == "cuda":
                pipe.enable_model_cpu_offload()
            else:
                pipe.to(device)

            if config.get("attention_slicing", True):
                pipe.enable_attention_slicing()
            if config.get("vae_slicing", True) and hasattr(pipe, "enable_vae_slicing"):
                pipe.enable_vae_slicing()

            self.pipe = pipe
            try:
                self.img2img_pipe = AutoPipelineForImage2Image.from_pipe(pipe)
            except Exception:
                self.img2img_pipe = None
            self.loaded_path = str(p)
            self.status = "模型已載入"
            self.error = ""
            return {"ok": True, "path": str(p)}
        except Exception as e:
            self.status = "載入失敗"
            self.error = str(e)
            raise

    def load_lora(self, path, scale):
        if self.pipe is None:
            raise RuntimeError("請先載入基礎模型")
        p = Path(path)
        if not p.exists():
            raise FileNotFoundError(f"LoRA 不存在：{p}")
        name = f"adapter_{len(self.loras)+1}"
        self.pipe.load_lora_weights(str(p.parent), weight_name=p.name, adapter_name=name)
        try:
            self.pipe.set_adapters([name], adapter_weights=[float(scale)])
        except Exception:
            pass
        self.loras.append({"path": str(p), "scale": float(scale), "adapter": name})
        return self.loras

    def generate(self, payload):
        if self.pipe is None:
            raise RuntimeError("請先載入模型")
        import torch
        dev = "cuda" if config.get("device") == "cuda" and torch.cuda.is_available() else "cpu"
        gen = torch.Generator(device=dev).manual_seed(int(payload.get("seed", 0)))
        result = self.pipe(
            prompt=payload.get("prompt", ""),
            negative_prompt=payload.get("negative_prompt") or None,
            width=int(payload.get("width", 512)),
            height=int(payload.get("height", 512)),
            num_inference_steps=int(payload.get("steps", 25)),
            guidance_scale=float(payload.get("guidance", 7)),
            num_images_per_prompt=int(payload.get("count", 1)),
            generator=gen
        )
        return result.images

engine = Engine()

def save_image(image, metadata):
    name = f"{time.strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:8]}.png"
    path = OUTPUTS / name
    image.save(path)
    item = {"file": name, "url": f"/outputs/{name}", "time": time.time(), **metadata}
    history.insert(0, item)
    del history[200:]
    save_json(HISTORY_FILE, history)
    return item

@app.get("/", response_class=HTMLResponse)
def index():
    return (STATIC / "index.html").read_text(encoding="utf-8")

@app.get("/api/diagnostics")
def api_diagnostics():
    return diagnostics()

@app.get("/api/status")
def api_status():
    return {
        "status": engine.status,
        "error": engine.error,
        "loaded_model": engine.loaded_path,
        "loras": engine.loras,
        "config": config
    }

@app.get("/api/models")
def api_models():
    return {"models": scan_models(), "loras": scan_loras()}

@app.post("/api/config")
def api_config(payload: dict):
    config.update(payload)
    save_json(CONFIG_FILE, config)
    return {"ok": True, "config": config}

@app.post("/api/model/load")
def api_load_model(payload: dict):
    try:
        return engine.load(payload.get("path", ""))
    except Exception as e:
        raise HTTPException(500, str(e))

@app.post("/api/model/unload")
def api_unload():
    engine.unload()
    return {"ok": True}

@app.post("/api/lora/load")
def api_lora(payload: dict):
    try:
        return {"ok": True, "loras": engine.load_lora(payload["path"], payload.get("scale", 1.0))}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.post("/api/generate")
def api_generate(payload: dict):
    try:
        images = engine.generate(payload)
        return {"ok": True, "images": [save_image(x, {"mode":"txt2img", **payload}) for x in images]}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.post("/api/img2img")
async def api_img2img(
    image: UploadFile = File(...),
    prompt: str = Form(""),
    negative_prompt: str = Form(""),
    strength: float = Form(0.65),
    steps: int = Form(25),
    guidance: float = Form(7),
    seed: int = Form(0)
):
    if engine.pipe is None:
        raise HTTPException(500, "請先載入模型")
    try:
        import torch
        from diffusers import AutoPipelineForImage2Image
        if engine.img2img_pipe is None:
            engine.img2img_pipe = AutoPipelineForImage2Image.from_pipe(engine.pipe)
        source = Image.open(io.BytesIO(await image.read())).convert("RGB")
        dev = "cuda" if config.get("device") == "cuda" and torch.cuda.is_available() else "cpu"
        gen = torch.Generator(device=dev).manual_seed(seed)
        out = engine.img2img_pipe(
            image=source, prompt=prompt, negative_prompt=negative_prompt or None,
            strength=strength, num_inference_steps=steps,
            guidance_scale=guidance, generator=gen
        ).images[0]
        return {"ok": True, "image": save_image(out, {
            "mode":"img2img","prompt":prompt,"negative_prompt":negative_prompt,
            "strength":strength,"steps":steps,"guidance":guidance,"seed":seed
        })}
    except Exception as e:
        raise HTTPException(500, str(e))

@app.get("/api/history")
def api_history():
    return {"history": history}

@app.delete("/api/history")
def api_clear_history():
    history.clear()
    save_json(HISTORY_FILE, history)
    return {"ok": True}

@app.post("/api/open-folder")
def api_open_folder(payload: dict):
    name = payload.get("name", "models")
    target = {"models": MODELS, "loras": LORAS, "outputs": OUTPUTS}.get(name, MODELS)
    if os.name == "nt":
        os.startfile(str(target))
    return {"ok": True}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app:app", host="127.0.0.1", port=7865, reload=False)
