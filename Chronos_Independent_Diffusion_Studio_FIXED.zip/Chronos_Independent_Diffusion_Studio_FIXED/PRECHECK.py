import importlib, sys
from pathlib import Path

print("="*60)
print("Chronos preflight check")
print("="*60)
print("Python:", sys.version)
print("Executable:", sys.executable)

mods = ["fastapi","uvicorn","PIL","torch","diffusers","transformers","accelerate","safetensors","peft"]
missing=[]
for m in mods:
    try:
        mod=importlib.import_module(m)
        print(f"[OK] {m} {getattr(mod,'__version__','')}")
    except Exception as e:
        print(f"[MISSING] {m}: {e}")
        missing.append(m)

try:
    import torch
    print("CUDA available:", torch.cuda.is_available())
    print("Torch CUDA:", torch.version.cuda)
    if torch.cuda.is_available():
        print("GPU:", torch.cuda.get_device_name(0))
except Exception:
    pass

models=Path("models")
found=list(models.rglob("*.safetensors"))+list(models.rglob("*.ckpt"))+list(models.rglob("model_index.json"))
print("Model files found:", len(found))
if not found:
    print("[WARNING] No model was found in the models folder.")

if missing:
    print("[ERROR] Run INSTALL_ALL.bat again.")
else:
    print("[OK] Core packages are installed.")
print("="*60)
