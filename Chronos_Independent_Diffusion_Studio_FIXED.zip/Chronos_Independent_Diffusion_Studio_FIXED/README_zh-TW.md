# Chronos Independent Diffusion Studio

這是一個獨立的 Stable Diffusion 類圖像程式。

它不啟動、不控制、也不連接：

- Kohya_ss
- AUTOMATIC1111
- ComfyUI

本程式直接使用 PyTorch、Diffusers、Transformers 與本機模型權重執行生成。

## 已完成的功能

- 文字生圖
- 圖片生圖
- 本機 Diffusers 模型載入
- `.safetensors` / `.ckpt` 單檔模型載入
- LoRA 載入
- 簡易 JSON 節點工作流
- CUDA / CPU 選擇
- float16 / bfloat16 / float32
- 低 VRAM 模式
- Attention slicing
- VAE slicing
- 圖片歷史紀錄
- PNG 生成參數 metadata
- LoRA 訓練設定介面

## 尚未完成

完整 LoRA 訓練反向傳播核心目前未啟用。訓練設定介面已建立，下一階段可加入：

- 圖片 caption
- Dataset bucketing
- UNet / Text Encoder 訓練
- AdamW8bit
- Gradient accumulation
- Checkpoint resume
- Preview samples
- TensorBoard

## 安裝

1. 安裝 Python 3.10 或 3.11。
2. NVIDIA 使用者先安裝與顯示卡相符的 PyTorch CUDA 版本。
3. 執行 `INSTALL.bat`。
4. 將模型放入 `models`。
5. 執行 `START.bat`。
6. 瀏覽器開啟 `http://127.0.0.1:7865`。

## 模型格式

支援：

- Diffusers 格式資料夾，內含 `model_index.json`
- Stable Diffusion `.safetensors`
- Stable Diffusion `.ckpt`

模型本身不包含在 ZIP 中，因為模型通常有數 GB 大小，而且不同模型具有不同授權。
