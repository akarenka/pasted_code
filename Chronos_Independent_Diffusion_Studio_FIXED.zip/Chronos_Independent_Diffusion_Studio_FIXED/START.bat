@echo off
cd /d "%~dp0"
title Chronos Independent Diffusion Studio
where py >nul 2>nul
if %errorlevel%==0 (
  start "" http://127.0.0.1:7865
  py app.py
) else (
  start "" http://127.0.0.1:7865
  python app.py
)
pause
