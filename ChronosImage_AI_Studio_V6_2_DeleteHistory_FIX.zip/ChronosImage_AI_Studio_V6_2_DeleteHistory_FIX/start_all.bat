@echo off
title ChronosImage AI Studio v6
cd /d "%~dp0"
if not exist .env copy .env.example .env
start "ChronosImage Backend" cmd /k "cd /d %~dp0 && python app.py"
timeout /t 2 /nobreak >nul
start "" "%~dp0index.html"
