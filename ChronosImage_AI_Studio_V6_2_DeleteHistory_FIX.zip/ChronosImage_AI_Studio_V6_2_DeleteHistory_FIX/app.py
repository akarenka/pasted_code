import os, base64, uuid, html, traceback, json, random
from datetime import datetime
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
from dotenv import load_dotenv

load_dotenv()
BASE_DIR=os.path.dirname(os.path.abspath(__file__))
DIRS={k:os.path.join(BASE_DIR,k) for k in ["outputs","logs","history","prompts","uploads","favorites","projects","exports","storyboards"]}
for d in DIRS.values(): os.makedirs(d,exist_ok=True)
app=Flask(__name__)
CORS(app)

STYLE={
"cinematic":"cinematic concept art, dramatic composition, premium commercial AI image style",
"anime":"high-end anime illustration, clean line art, rich shading, polished character-art quality",
"realistic":"photorealistic, natural material detail, professional photography quality",
"3d render":"high-end 3D render, global illumination, realistic materials, octane render look",
"watercolor":"premium watercolor illustration, soft paper texture, elegant brush details",
"cyberpunk":"cyberpunk neon atmosphere, rain reflections, futuristic city detail",
"fantasy":"epic fantasy illustration, magical atmosphere, highly detailed environment",
"storyboard":"clean professional storyboard frame, clear composition, cinematic shot planning"
}
LIGHT={"cinematic":"cinematic lighting, volumetric light, rim light","soft":"soft diffused lighting","neon":"neon glow, colored reflections","golden":"golden hour lighting","studio":"professional studio lighting"}
CAMERA={"wide":"wide angle, dynamic perspective","portrait":"portrait composition, shallow depth of field","macro":"macro detail, close-up texture","low angle":"low angle shot, heroic scale","top down":"top-down composition"}
DETAIL={"normal":"high detail","ultra":"ultra detailed, intricate details, sharp focus","insane":"insanely detailed, premium rendering, crisp edges","clean":"clean composition, clear silhouette"}
MOOD={"epic":"epic, powerful, majestic","dreamy":"dreamy, ethereal, magical","dark":"dark, mysterious, intense","cute":"cute, charming, friendly","luxury":"luxury, elegant, premium"}
RANDOM_PROMPTS=["一條發光機械龍飛過東京夜空，電影感，高細節","穿著機械裝甲的武士站在月光下","未來城市中的水晶塔，霓虹光，雨夜反射","漂浮在雲海上的魔法圖書館"]

def jload(p,d):
    if not os.path.exists(p): return d
    try:
        with open(p,"r",encoding="utf-8") as f: return json.load(f)
    except Exception: return d
def jsave(p,d):
    with open(p,"w",encoding="utf-8") as f: json.dump(d,f,ensure_ascii=False,indent=2)
def log_error(e):
    with open(os.path.join(DIRS["logs"],"error.log"),"a",encoding="utf-8") as f:
        f.write("\n"+"="*70+"\n"+datetime.now().isoformat()+"\n"+str(e)+"\n"+traceback.format_exc()+"\n")
def save_file(data,ext,prefix="chronos_v6"):
    name=f"{prefix}_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}.{ext}"
    with open(os.path.join(DIRS["outputs"],name),"wb") as f: f.write(data)
    return name
def quality_score(d):
    score=50
    if d.get("enhance",True): score+=12
    if d.get("detail") in ["ultra","insane"]: score+=10
    if d.get("lighting") in ["cinematic","studio","golden"]: score+=8
    if d.get("reference_filename"): score+=10
    if d.get("negative"): score+=5
    if d.get("quality")=="masterpiece": score+=10
    return min(score,100)
def build_prompt(d, frame=None):
    prompt=(d.get("prompt") or "").strip()
    if frame:
        prompt=f"{prompt}\n\nStoryboard frame {frame['index']}: {frame['shot']} — {frame['action']} — Camera: {frame['camera']} — Mood: {frame['mood']}"
    style=STYLE.get(d.get("style","cinematic"),d.get("style","cinematic"))
    lighting=LIGHT.get(d.get("lighting","cinematic"),"cinematic lighting")
    camera=CAMERA.get(d.get("camera","wide"),"wide angle")
    detail=DETAIL.get(d.get("detail","ultra"),"ultra detailed")
    mood=MOOD.get(d.get("mood","epic"),"epic")
    negative=(d.get("negative") or "").strip()
    ref=d.get("reference_filename") or ""
    strength=d.get("reference_strength") or "medium"
    parts=[prompt,"","COMMERCIAL QUALITY IMAGE PROMPT:",
           f"- Style: {style}",f"- Lighting: {lighting}",f"- Camera: {camera}",f"- Detail: {detail}",f"- Mood: {mood}",
           f"- Quality target: {d.get('quality','masterpiece')}, polished, professional, market-ready",
           "- Composition: clear subject, strong silhouette, balanced layout, refined color harmony"]
    if ref:
        parts.append(f"- Use uploaded reference image as visual guide: {ref}")
        parts.append(f"- Reference strength: {strength}; preserve important shapes, identity, pose, colors when useful")
    if negative: parts.append(f"- Avoid: {negative}")
    return "\n".join(parts)
def svg_mock(d, enhanced, idx=1, title="ChronosImage v6 Mock"):
    aspect=d.get("aspect","1:1")
    if aspect=="16:9": w,h=1344,768
    elif aspect=="9:16": w,h=768,1344
    else: w,h=1024,1024
    p=html.escape((d.get("prompt") or "")[:650]); e=html.escape(enhanced[:1250])
    ref=html.escape(d.get("reference_filename") or "none")
    def wrap(txt,n):
        words=txt.split(); lines=[]; cur=""
        for word in words:
            if len(cur)+len(word)>n:
                lines.append(cur); cur=word
            else: cur=(cur+" "+word).strip()
        if cur: lines.append(cur)
        return lines
    y=260
    lines=[
    f'<text x="70" y="105" fill="#19e6ff" font-size="46" font-family="Arial" font-weight="700">{html.escape(title)}</text>',
    f'<text x="70" y="165" fill="#fff176" font-size="25" font-family="Arial">Quality {quality_score(d)}/100 | Reference: {ref} | Frame/Batch: {idx}</text>',
    '<text x="70" y="215" fill="#9df7ff" font-size="28" font-family="Arial">Prompt:</text>']
    for line in wrap(p,48)[:5]:
        lines.append(f'<text x="70" y="{y}" fill="#eafcff" font-size="23" font-family="Arial">{line}</text>'); y+=32
    y+=18; lines.append(f'<text x="70" y="{y}" fill="#ff9ff3" font-size="24" font-family="Arial">Enhanced:</text>'); y+=32
    for line in wrap(e,66)[:12]:
        lines.append(f'<text x="70" y="{y}" fill="#bafcff" font-size="18" font-family="Arial">{line}</text>'); y+=26
    svg=f"""<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0%" stop-color="#030512"/><stop offset="45%" stop-color="#111b45"/><stop offset="100%" stop-color="#002b3a"/></linearGradient><filter id="glow"><feGaussianBlur stdDeviation="5" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>
<rect width="100%" height="100%" fill="url(#g)"/><rect x="36" y="36" width="{w-72}" height="{h-72}" rx="30" fill="none" stroke="#19e6ff" stroke-width="4" filter="url(#glow)"/>
<circle cx="{int(w*.78)}" cy="{int(h*.25)}" r="{int(min(w,h)*.12)}" fill="#19e6ff" opacity=".13"/><circle cx="{int(w*.84)}" cy="{int(h*.31)}" r="{int(min(w,h)*.065)}" fill="#ff4fd8" opacity=".16"/>
<path d="M {int(w*.54)} {int(h*.76)} C {int(w*.70)} {int(h*.48)}, {int(w*.86)} {int(h*.93)}, {int(w*.97)} {int(h*.60)}" fill="none" stroke="#19e6ff" stroke-width="4" opacity=".42"/>
{''.join(lines)}</svg>"""
    return svg.encode("utf-8")
def save_history(item):
    path=os.path.join(DIRS["history"],"history.json"); data=jload(path,[]); data.insert(0,item); jsave(path,data[:800])
def upload_url(fn):
    port=os.getenv("PORT","7860")
    return f"http://127.0.0.1:{port}/uploads/{fn}"
def openai_image(prompt,size):
    from openai import OpenAI
    key=os.getenv("OPENAI_API_KEY","").strip()
    if not key: raise RuntimeError("OPENAI_API_KEY is empty. Edit .env first.")
    client=OpenAI(api_key=key)
    res=client.images.generate(model="gpt-image-1",prompt=prompt,size=size)
    return base64.b64decode(res.data[0].b64_json),"png"
def gemini_image(prompt,size,ref_filename=None):
    key=os.getenv("GEMINI_API_KEY","").strip()
    if not key: raise RuntimeError("GEMINI_API_KEY is empty. Edit .env first.")
    from google import genai
    from google.genai import types
    client=genai.Client(api_key=key)
    contents=[f"Create a refined commercial-quality AI image:\n{prompt}\nSize: {size}"]
    if ref_filename:
        path=os.path.join(DIRS["uploads"],ref_filename)
        if os.path.exists(path):
            with open(path,"rb") as f:
                image_bytes=f.read()
            mime="image/png"
            low=ref_filename.lower()
            if low.endswith(".jpg") or low.endswith(".jpeg"): mime="image/jpeg"
            elif low.endswith(".webp"): mime="image/webp"
            contents.append(types.Part.from_bytes(data=image_bytes, mime_type=mime))
    res=client.models.generate_content(model="gemini-2.5-flash-image-preview",contents=contents,config=types.GenerateContentConfig(response_modalities=["IMAGE","TEXT"]))
    for part in res.candidates[0].content.parts:
        if getattr(part,"inline_data",None): return part.inline_data.data,"png"
    raise RuntimeError("Gemini returned no image")
def gen_one(d,idx=1,frame=None):
    if not (d.get("prompt") or "").strip(): raise RuntimeError("Prompt is empty")
    provider=(d.get("provider") or "mock").lower()
    enhanced=build_prompt(d,frame) if bool(d.get("enhance",True)) else d.get("prompt")
    size=d.get("size","1024x1024")
    if provider=="mock": b=svg_mock(d,enhanced,idx,"ChronosImage v6 Image/Storyboard Mock"); ext="svg"
    elif provider=="openai": b,ext=openai_image(enhanced,size)
    elif provider=="gemini": b,ext=gemini_image(enhanced,size,d.get("reference_filename"))
    else: raise RuntimeError("Unknown provider")
    filename=save_file(b,ext); port=os.getenv("PORT","7860"); url=f"http://127.0.0.1:{port}/outputs/{filename}"
    item={"time":datetime.now().isoformat(timespec="seconds"),"provider":provider,"style":d.get("style"),"size":size,"aspect":d.get("aspect"),"prompt":d.get("prompt"),"enhanced":enhanced,"filename":filename,"url":url,"quality_score":quality_score(d),"settings":d}
    if frame: item["storyboard_frame"]=frame
    save_history(item); jsave(os.path.join(DIRS["exports"],filename+".json"),item)
    return item

@app.get("/health")
def health(): return jsonify({"ok":True,"service":"ChronosImage AI Studio v6","message":"Backend connected"})
@app.get("/outputs/<path:filename>")
def outputs(filename): return send_from_directory(DIRS["outputs"],filename)
@app.get("/uploads/<path:filename>")
def uploads(filename): return send_from_directory(DIRS["uploads"],filename)
@app.get("/history")
def history(): return jsonify({"ok":True,"items":jload(os.path.join(DIRS["history"],"history.json"),[])})
@app.get("/random_prompt")
def random_prompt(): return jsonify({"ok":True,"prompt":random.choice(RANDOM_PROMPTS)})
@app.post("/upload_reference")
def upload_reference():
    if "file" not in request.files: return jsonify({"ok":False,"error":"No file uploaded"}),400
    f=request.files["file"]; ext=(f.filename.rsplit(".",1)[-1].lower() if "." in f.filename else "bin")
    name=f"ref_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}.{ext}"
    f.save(os.path.join(DIRS["uploads"],name))
    return jsonify({"ok":True,"filename":name,"url":upload_url(name),"message":"Reference saved. Select Gemini for real image-to-image, or Mock for preview."})
@app.post("/quality_preview")
def quality_preview():
    d=request.get_json(force=True)
    if not (d.get("prompt") or "").strip(): return jsonify({"ok":False,"error":"Prompt is empty"}),400
    return jsonify({"ok":True,"score":quality_score(d),"enhanced":build_prompt(d)})
@app.post("/generate")
def generate():
    try: return jsonify({"ok":True,**gen_one(request.get_json(force=True),1)})
    except Exception as e: log_error(e); return jsonify({"ok":False,"error":str(e)}),500
@app.post("/batch_generate")
def batch_generate():
    try:
        d=request.get_json(force=True); count=max(1,min(int(d.get("count") or 1),8))
        return jsonify({"ok":True,"items":[gen_one(d,i+1) for i in range(count)]})
    except Exception as e: log_error(e); return jsonify({"ok":False,"error":str(e)}),500
@app.post("/make_storyboard")
def make_storyboard():
    try:
        d=request.get_json(force=True)
        scene=(d.get("story_scene") or d.get("prompt") or "").strip()
        frames=max(2,min(int(d.get("story_frames") or 6),12))
        shot_cycle=["Establishing wide shot","Medium shot","Close-up","Over-the-shoulder shot","Low angle action shot","Final dramatic wide shot"]
        mood_cycle=["setup","tension","emotion","action","climax","resolution"]
        board=[]
        for i in range(frames):
            board.append({"index":i+1,"shot":shot_cycle[i%len(shot_cycle)],"action":f"{scene} — beat {i+1}", "camera":d.get("camera","wide"), "mood":mood_cycle[i%len(mood_cycle)]})
        name=f"storyboard_{datetime.now().strftime('%Y%m%d_%H%M%S')}_{uuid.uuid4().hex[:6]}.json"
        jsave(os.path.join(DIRS["storyboards"],name),{"scene":scene,"frames":board,"settings":d})
        return jsonify({"ok":True,"file":name,"frames":board})
    except Exception as e: log_error(e); return jsonify({"ok":False,"error":str(e)}),500
@app.post("/generate_storyboard_images")
def generate_storyboard_images():
    try:
        d=request.get_json(force=True)
        frames=d.get("frames") or []
        items=[]
        old_style=d.get("style")
        d["style"]="storyboard" if d.get("storyboard_style")=="sketch" else old_style
        for i,frame in enumerate(frames[:12]):
            items.append(gen_one(d,i+1,frame))
        d["style"]=old_style
        return jsonify({"ok":True,"items":items})
    except Exception as e: log_error(e); return jsonify({"ok":False,"error":str(e)}),500
@app.post("/save_prompt")
def save_prompt():
    d=request.get_json(force=True); name=(d.get("name") or "prompt").strip(); prompt=(d.get("prompt") or "").strip()
    if not prompt: return jsonify({"ok":False,"error":"Prompt is empty"}),400
    safe="".join(c for c in name if c.isalnum() or c in " _-")[:80] or "prompt"
    with open(os.path.join(DIRS["prompts"],safe+".txt"),"w",encoding="utf-8") as f: f.write(prompt)
    return jsonify({"ok":True,"file":safe+".txt"})
@app.get("/prompts")
def prompts():
    items=[]
    for fn in os.listdir(DIRS["prompts"]):
        if fn.endswith(".txt"):
            with open(os.path.join(DIRS["prompts"],fn),"r",encoding="utf-8") as f: items.append({"name":fn,"text":f.read()})
    return jsonify({"ok":True,"items":items})

@app.post("/delete_history")
def delete_history():
    try:
        data = request.get_json(force=True)
        filename = data.get("filename")
        if not filename:
            return jsonify({"ok": False, "error": "filename required"}), 400

        hist_path = os.path.join(DIRS["history"], "history.json")
        items = jload(hist_path, [])
        new_items = [x for x in items if x.get("filename") != filename]
        jsave(hist_path, new_items)

        # delete generated output file
        out_path = os.path.join(DIRS["outputs"], filename)
        if os.path.exists(out_path):
            os.remove(out_path)

        # delete metadata export if exists
        exp_path = os.path.join(DIRS["exports"], filename + ".json")
        if os.path.exists(exp_path):
            os.remove(exp_path)

        return jsonify({"ok": True, "deleted": filename, "remaining": len(new_items)})
    except Exception as e:
        log_error(e)
        return jsonify({"ok": False, "error": str(e)}), 500

@app.post("/clear_history")
def clear_history():
    try:
        data = request.get_json(force=True) if request.data else {}
        delete_outputs = bool(data.get("delete_outputs", True))

        hist_path = os.path.join(DIRS["history"], "history.json")
        old_items = jload(hist_path, [])

        if delete_outputs:
            for item in old_items:
                fn = item.get("filename")
                if fn:
                    out_path = os.path.join(DIRS["outputs"], fn)
                    if os.path.exists(out_path):
                        os.remove(out_path)
                    exp_path = os.path.join(DIRS["exports"], fn + ".json")
                    if os.path.exists(exp_path):
                        os.remove(exp_path)

        jsave(hist_path, [])
        return jsonify({"ok": True, "cleared": len(old_items)})
    except Exception as e:
        log_error(e)
        return jsonify({"ok": False, "error": str(e)}), 500

if __name__=="__main__":
    port=int(os.getenv("PORT","7860"))
    print("ChronosImage AI Studio v6 backend running")
    print(f"Open: http://127.0.0.1:{port}/health")
    app.run(host="127.0.0.1",port=port,debug=True)
