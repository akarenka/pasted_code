@echo off
title ChronosImage AI Studio v6 Install
cd /d "%~dp0"
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if not exist .env copy .env.example .env
echo Install finished.
pause
