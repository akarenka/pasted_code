const API="http://127.0.0.1:7860";const $=id=>document.getElementById(id);let currentFilename="",historyItems=[],referenceFilename="",storyFrames=[];
function payload(){return{provider:$("provider").value,style:$("style").value,lighting:$("lighting").value,camera:$("camera").value,detail:$("detail").value,mood:$("mood").value,reference_filename:referenceFilename,reference_strength:$("reference_strength").value,count:$("batchCount").value,aspect:$("aspect").value,size:$("size").value,quality:"masterpiece",enhance:$("enhance").checked,prompt:$("prompt").value.trim(),negative:$("negative").value.trim(),story_scene:$("story_scene").value.trim(),story_frames:$("story_frames").value,storyboard_style:$("storyboard_style").value}}
async function health(){try{let r=await fetch(`${API}/health`),j=await r.json();$("status").textContent=j.ok?"Backend connected":"Backend error"}catch(e){$("status").textContent="Backend not connected"}}
async function quality(){let r=await fetch(`${API}/quality_preview`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload())}),j=await r.json();if(j.ok){$("score").textContent=j.score;$("enhancedText").textContent=j.enhanced}else $("status").textContent="Error: "+j.error}
function show(j){currentFilename=j.filename;$("resultImg").src=j.url+"?t="+Date.now();$("emptyPreview").style.display="none";$("downloadLink").href=j.url;$("downloadLink").style.display="inline-block";$("enhancedText").textContent=j.enhanced||"";$("score").textContent=j.quality_score||"--";$("status").textContent="Done: "+j.filename}
async function generate(){let r=await fetch(`${API}/generate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload())}),j=await r.json();if(j.ok){show(j);loadHistory()}else $("status").textContent="Error: "+j.error}
async function batch(){let r=await fetch(`${API}/batch_generate`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload())}),j=await r.json();if(j.ok){show(j.items[0]);loadHistory()}else $("status").textContent="Error: "+j.error}
async function uploadRef(){let file=$("refFile").files[0];if(!file){$("status").textContent="No file selected";return}let fd=new FormData();fd.append("file",file);let r=await fetch(`${API}/upload_reference`,{method:"POST",body:fd}),j=await r.json();if(j.ok){referenceFilename=j.filename;$("refName").textContent=j.filename;$("refPreview").src=j.url+"?t="+Date.now();$("status").textContent=j.message}else $("status").textContent="Error: "+j.error}
async function makeStoryboard(){let r=await fetch(`${API}/make_storyboard`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(payload())}),j=await r.json();if(j.ok){storyFrames=j.frames;renderStory();$("status").textContent="Storyboard ready: "+j.file}else $("status").textContent="Error: "+j.error}
async function genStoryboard(){if(!storyFrames.length){$("status").textContent="Make storyboard first";return}let r=await fetch(`${API}/generate_storyboard_images`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({...payload(),frames:storyFrames})}),j=await r.json();if(j.ok){show(j.items[0]);loadHistory();$("status").textContent="Storyboard images generated: "+j.items.length}else $("status").textContent="Error: "+j.error}
function renderStory(){let box=$("storyFrames");box.innerHTML="";storyFrames.forEach(f=>{let d=document.createElement("div");d.className="frame";d.innerHTML=`<b>#${f.index} ${f.shot}</b><br>${f.action}<br><small>Camera: ${f.camera} / Mood: ${f.mood}</small>`;box.appendChild(d)})}
async function randomPrompt(){let r=await fetch(`${API}/random_prompt`),j=await r.json();if(j.ok)$("prompt").value=j.prompt}
async function savePrompt(){let name=prompt("Prompt name?","image2image_prompt");if(!name)return;let r=await fetch(`${API}/save_prompt`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({name,prompt:$("prompt").value})}),j=await r.json();$("status").textContent=j.ok?"Saved "+j.file:"Error "+j.error;loadPrompts()}
async function loadHistory(){
  let r=await fetch(`${API}/history?t=${Date.now()}`);
  let j=await r.json();
  historyItems=j.items||[];
  renderHistory();
}

function renderHistory(){
  let q=($("historySearch").value||"").toLowerCase(),box=$("historyList");
  box.innerHTML="";
  historyItems
    .filter(i=>((i.prompt||"")+(i.provider||"")+(i.style||"")).toLowerCase().includes(q))
    .forEach(i=>{
      let score = (i.quality_score===undefined || i.quality_score===null) ? "--" : i.quality_score;
      let c=document.createElement("div");
      c.className="card";
      c.innerHTML=`<img src="${i.url}?t=${Date.now()}"><div class="meta">${i.time||""}<br>${i.provider||""} / ${i.style||""}<br>Score ${score}/100<br>${esc(i.prompt||"").slice(0,80)}</div><button class="deleteBtn">Delete this history</button>`;
      c.querySelector("img").onclick=()=>show(i);
      c.querySelector(".meta").onclick=()=>show(i);
      c.querySelector(".deleteBtn").onclick=async(ev)=>{
        ev.stopPropagation();
        if(!confirm("Delete this history record and image file?")) return;
        let r=await fetch(`${API}/delete_history`,{
          method:"POST",
          headers:{"Content-Type":"application/json"},
          body:JSON.stringify({filename:i.filename})
        });
        let j=await r.json();
        $("status").textContent=j.ok?`Deleted: ${i.filename}`:`Error: ${j.error}`;
        historyItems=historyItems.filter(x=>x.filename!==i.filename);
        renderHistory();
      };
      box.appendChild(c);
    });
}

async function clearAllHistory(){
  if(!confirm("Force clear ALL history and generated images?")) return;
  let r=await fetch(`${API}/clear_history`,{
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify({delete_outputs:true})
  });
  let j=await r.json();
  $("status").textContent=j.ok?`Cleared ${j.cleared} records and output files`:`Error: ${j.error}`;
  historyItems=[];
  renderHistory();
  $("resultImg").removeAttribute("src");
  $("emptyPreview").style.display="block";
  $("downloadLink").style.display="none";
}

async function loadPrompts(){let r=await fetch(`${API}/prompts`),j=await r.json(),box=$("promptList");box.innerHTML="";(j.items||[]).forEach(i=>{let c=document.createElement("span");c.className="chip";c.textContent=i.name;c.onclick=()=>{$("prompt").value=i.text};box.appendChild(c)})}
function esc(s){return(s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[m]))}
$("qualityBtn").onclick=quality;$("generateBtn").onclick=generate;$("batchBtn").onclick=batch;$("randomBtn").onclick=randomPrompt;$("uploadRefBtn").onclick=uploadRef;$("makeStoryboardBtn").onclick=makeStoryboard;$("generateStoryboardBtn").onclick=genStoryboard;$("savePromptBtn").onclick=savePrompt;$("refreshHistoryBtn").onclick=loadHistory;$("clearHistoryBtn").onclick=clearAllHistory;$("historySearch").oninput=renderHistory;
health();loadHistory();loadPrompts();
