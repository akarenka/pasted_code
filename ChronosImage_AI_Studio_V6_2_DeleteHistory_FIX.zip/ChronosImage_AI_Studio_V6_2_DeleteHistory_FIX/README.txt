ChronosImage AI Studio v6 Image-to-Image + Storyboard

Run:
1. install.bat
2. start_all.bat

New:
- Upload reference image
- Image-to-image prompt mode
- Reference strength
- Storyboard generator
- Storyboard frames export
- Storyboard text copy
- Mock preview works without API key

For real image-to-image:
- Gemini provider supports using uploaded reference image in this demo path.
- OpenAI provider keeps a prepared hook; text-to-image is supported.


v6.1 added:
- Delete single history record
- Clear all history records
- Deletes related output image and metadata JSON


v6.2 FIX:
- Force Clear All History deletes all output images and metadata.
- Delete this history removes item immediately from UI.
- History auto-filters stale records when image files are missing.
- Score undefined is shown as --.
