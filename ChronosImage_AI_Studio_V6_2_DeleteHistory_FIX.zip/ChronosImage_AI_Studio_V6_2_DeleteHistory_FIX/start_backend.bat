@echo off
title ChronosImage AI Studio v6 Backend
cd /d "%~dp0"
if not exist .env copy .env.example .env
python app.py
pause
